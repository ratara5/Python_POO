#It's possible create any quantity of modules in only one package

def potentiation(op1,op2):
    print('Potentiation is: {}'.format(op1**op2))

def to_round(number):
    print('Round is: {}'.format(round(number)))
