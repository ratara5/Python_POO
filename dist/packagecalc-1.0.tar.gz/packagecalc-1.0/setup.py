from setuptools import setup

setup(    
    name='packagecalc',
    version='1.0',
    description='package round and potentiation',
    author='me',
    author_email='me@mail.com',
    url='www.mwweb.com',
    packages=['package','package']
    )